package SharedPreview::L10N::en_us;
use strict;
use warnings;

use base 'SharedPreview::L10N';

our %Lexicon = ();

1;

